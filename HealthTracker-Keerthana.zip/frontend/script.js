
// Health Tracker frontend logic by Keerthana
const API_URL = 'http://localhost:5000/api/entries';

async function fetchEntries() {
  const res = await fetch(API_URL);
  const entries = await res.json();
  const list = document.getElementById('entryList');
  list.innerHTML = '';
  entries.forEach(entry => {
    const li = document.createElement('li');
    li.textContent = `${new Date(entry.date).toLocaleDateString()} - Steps: ${entry.steps}, Calories: ${entry.calories}, Water: ${entry.waterIntake}L`;
    list.appendChild(li);
  });
}

async function addEntry() {
  const date = document.getElementById('date').value;
  const steps = document.getElementById('steps').value;
  const calories = document.getElementById('calories').value;
  const water = document.getElementById('water').value;

  if (!date || (!steps && !calories && !water)) return;

  await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ date, steps, calories, waterIntake: water })
  });

  fetchEntries();
}

window.onload = fetchEntries;

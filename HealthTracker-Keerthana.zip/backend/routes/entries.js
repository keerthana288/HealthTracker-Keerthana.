
// Health entry routes by Keerthana
const express = require('express');
const router = express.Router();
const Entry = require('../models/Entry');

router.get('/', async (req, res) => {
  const entries = await Entry.find();
  res.json(entries);
});

router.post('/', async (req, res) => {
  const newEntry = new Entry(req.body);
  const savedEntry = await newEntry.save();
  res.json(savedEntry);
});

router.delete('/:id', async (req, res) => {
  await Entry.findByIdAndDelete(req.params.id);
  res.json({ message: 'Entry deleted' });
});

module.exports = router;


// Health entry model by Keerthana
const mongoose = require('mongoose');

const entrySchema = new mongoose.Schema({
  date: { type: Date, required: true },
  steps: Number,
  calories: Number,
  waterIntake: Number,
});

module.exports = mongoose.model('Entry', entrySchema);
